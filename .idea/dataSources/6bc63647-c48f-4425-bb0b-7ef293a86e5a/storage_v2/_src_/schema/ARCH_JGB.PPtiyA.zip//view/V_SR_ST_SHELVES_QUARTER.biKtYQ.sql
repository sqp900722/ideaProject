create view V_SR_ST_SHELVES_QUARTER as
select t2.storeroom_name,
       t1.archive_type,
       filingtype,
       t1.shelves_quarter
  from (select v.storeroom_id, t.archive_type, a.filingtype,
       substr(t.shelves_date, 1, 4) ||
       (case
          when substr(t.shelves_date, 6, 2) = '01' or substr(t.shelves_date, 6, 2) = '02' or substr(t.shelves_date, 6, 2) = '03' then
           'S1'
          when substr(t.shelves_date, 6, 2) = '04' or substr(t.shelves_date, 6, 2) = '05' or substr(t.shelves_date, 6, 2) = '06' then
           'S2'
          when substr(t.shelves_date, 6, 2) = '07' or substr(t.shelves_date, 6, 2) = '08' or substr(t.shelves_date, 6, 2) = '09' then
           'S3'
          when substr(t.shelves_date, 6, 2) = '10' or substr(t.shelves_date, 6, 2) = '11' or substr(t.shelves_date, 6, 2) = '12' then
           'S4'
          else
           ''
        end) shelves_quarter
          from v_sr_cell_storeroom       v,
               t_sr_shelve_detail_entity t,
               v_archive_total           a
         where a.id = t.owner_id
           and v.cell_id = t.cell_id) t1,
       t_sr_storeroom t2
/

