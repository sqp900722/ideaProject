create view V_SR_SHELVE_DETAIL_ALL as
  (select id,cell_id from   t_sr_shelve_detail_entity  where shelves_box_id is null union all select id,cell_id from  t_sr_shelve_detail_box)
/

