create view T_ARCHIVE_SYSTEM_PARAMETER as
select t.name as PARA_KEY,t.value as PARA_VALUE,t.remark as PARA_REMARK,t.value as DEFAULT_KEY,t.id as PARA_ID,t.name as PARA_NAME,'' as FLAG from t_xtpz_system_param t
/

