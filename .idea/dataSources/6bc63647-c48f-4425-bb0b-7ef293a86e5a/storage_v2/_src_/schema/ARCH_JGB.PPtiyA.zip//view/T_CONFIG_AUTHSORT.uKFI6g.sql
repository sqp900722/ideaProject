create view T_CONFIG_AUTHSORT as
select id as unique_code,
       column_id dict_unique_code,
       show_order sort_no,
       sort_type sort_style,
       ''  comments,
       '0' user_id,
       '0'  org_id,
       ''  dict_base_unique_code
   from t_xtpz_app_sort
/

