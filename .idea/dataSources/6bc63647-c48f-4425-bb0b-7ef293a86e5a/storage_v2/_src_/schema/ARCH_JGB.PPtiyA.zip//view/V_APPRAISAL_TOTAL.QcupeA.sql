create view V_APPRAISAL_TOTAL as
  select substr(t1.APPRAISAL_DATE,0,4)as APPRAISAL_YEAR, t2.group_name, '开放鉴定' as APPRAISAL_type,t1.is_delete
from t_ap_batch_kf t1,t_xtpz_physical_group_define t2
where
t2.id=t1.archive_type_id
union all
select substr(t1.APPRAISAL_DATE,0,4)as APPRAISAL_YEAR, t2.group_name, '处置鉴定' as APPRAISAL_type,t1.is_delete
from t_ap_batch_cz t1,t_xtpz_physical_group_define t2
where
t2.id=t1.archive_type_id
union all
select substr(t1.APPRAISAL_DATE,0,4)as APPRAISAL_YEAR, t2.group_name, '处置鉴定' as APPRAISAL_type,t1.is_delete
from t_ap_batch_cz t1,t_xtpz_physical_group_define t2
 where
t2.id=t1.archive_type_id
union all
select substr(t1.APPRAISAL_DATE,0,4)as APPRAISAL_YEAR, t2.group_name, '密级鉴定' as APPRAISAL_type,t1.is_delete
from t_ap_batch_mj t1,t_xtpz_physical_group_define t2
where
t2.id=t1.archive_type_id
union all
select substr(t1.APPRAISAL_DATE,0,4)as APPRAISAL_YEAR, t2.group_name, '划控鉴定' as APPRAISAL_type,t1.is_delete
from t_ap_batch_hk t1,t_xtpz_physical_group_define t2
 where
t2.id=t1.archive_type_id
/

