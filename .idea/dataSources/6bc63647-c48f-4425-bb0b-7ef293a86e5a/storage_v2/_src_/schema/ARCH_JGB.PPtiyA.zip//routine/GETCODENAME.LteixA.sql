create function getCodeName(isCode in number, codeValue in varchar2, codeTypeCode in varchar2)
         return varchar2 is codeName varchar2(100);
         temp_number number := 0;
begin
    if isCode = 0 then
        return codeValue;
    end if;
    select count(*) into temp_number from t_xtpz_code tc
           where tc.code_type_code = codeTypeCode and tc.value = codeValue;
    if temp_number > 0 then
        select tc.name into codeName from t_xtpz_code tc
              where tc.code_type_code = codeTypeCode and tc.value = codeValue;
    end if;
    if (temp_number = 0 or codeName is null) then
        codeName := codeValue;
    end if;
    return codeName;
end getCodeName;

--????"/"
/

