create view V_CP_CONTENT_INFO as
select t."ID",t."CREATE_USER",t."CREATE_TIME",t."UPDATE_USER",t."UPDATE_TIME",t."IS_DELETE",t."DELETE_USER",t."DELETE_TIME",t."STATUS",t."SUBJECT_ID",t."P_ID",t."NAME",t."START_TIME",t."END_TIME",t."IS_CATALOG",t."SHOW_ORDER",t."CONTENT_LEVEL",t."PAGE_NUM",t."FILE_NAME",t."FILE_URL",
        (select a.user_id from t_cp_content_user a where a.user_type='1' and a.content_id=t.id) as cpuserid,
        (select a.user_id from t_cp_content_user a where a.user_type='2' and a.content_id=t.id) as ckuserid,
        (select a.user_id from t_cp_content_user a where a.user_type='3' and a.content_id=t.id) as reuserid
    from t_cp_content t
/

