create view T_CONFIG_AUTHLIST as
select t.id as UNIQUE_CODE,t.column_id as DICT_UNIQUE_CODE,t.show_order as SHOW_NO,t.show_name as SHOW_TITLE,t.width as SHOW_WIDTH,t.align as SHOW_ALIGN,'' as COMMENTS,'0' as USER_ID,'' as ORG_ID from T_XTPZ_APP_COLUMN t where t.component_version_id='-1' and t.menu_id='-1'
/

