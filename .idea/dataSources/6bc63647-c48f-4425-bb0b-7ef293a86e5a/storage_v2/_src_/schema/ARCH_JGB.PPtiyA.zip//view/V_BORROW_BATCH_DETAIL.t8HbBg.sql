create view V_BORROW_BATCH_DETAIL as
select substr(a.BORROW_DATE, 0, 4) as borrow_year,substr(a.BORROW_DATE, 0, 4) as return_year,b.ARCHIVE_TYPE,a.DEPT_ID,case when a.BORROW_TYPE = '1' then '????' when a.BORROW_TYPE = '2' then '????' when a.BORROW_TYPE = '3' then '??/????' end as BORROW_TYPE,d.logic_table_code as filingtype from T_PS_BORROW a,T_PS_BORROW_DETAIL b,t_xtpz_physical_table_define d where a.id = b.borrow_id and b.table_id = d.id
/

