create function fillZero(fillLen in number, str in varchar2, ch in varchar2) return varchar2 is rlt varchar2(255);
     strLen number(3);
begin
    rlt := str;
    select length(str) into strLen from dual;
    if strLen < fillLen then
      for i in 1..(fillLen - strLen)
        loop
          rlt := ch || rlt;
        end loop;
    end if;
    return rlt;
end fillZero;

--????"/"
/

