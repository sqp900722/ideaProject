create view T_CONFIG_DICT as
select t.id as UNIQUE_CODE,t.table_id as CODE,t.column_name as COL_NAME,t.show_name as SHOW_NAME,t.length as COLUMN_MAXLENGTH,t.column_type as COLUMN_TYPE,'2' as DICT_FLAG,'' as COLUMN_NULL,t.default_value as COLUMN_DEFAULT,'' as COMMENTS,t.show_order as COLUMN_ORDER,'1' as COLUMN_USE,'' as SUB,'1' as QUERY_FLAG,'2' JC_FLAG from T_XTPZ_COLUMN_DEFINE t where t.listable=1 and t.created=1
/

