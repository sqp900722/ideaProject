create view V_SR_SHELVE_STATUS_COUNT as
select store_room_id, shelve_status, count(*) shelve_status_count from (select store_room_id, cell_id, capacity, shelve_count, case when shelve_count = 0 then '？？？' when capacity - shelve_count = 0 then '？？？？' when capacity - shelve_count > 0 then 'δ？？' else '？？？？' end shelve_status from (select t4.id store_room_id, t.id cell_id, t.capacity capacity, (select count(*) shelve_count from v_sr_shelve_detail_all where cell_id = t.id) shelve_count from t_sr_storeroom_cell   t, t_sr_storeroom_column t2, t_sr_storeroom_zone   t3, t_sr_storeroom        t4 where t.column_id = t2.id and t2.zone_id = t3.id and t3.storeroom_id = t4.id)) group by store_room_id, shelve_status order by store_room_id, shelve_status
/

