create view V_SR_SHELVE_COUNT as
select t4.id store_room_id, count(t5.id) shelve_count from t_sr_storeroom_cell   t, t_sr_storeroom_column t2, t_sr_storeroom_zone   t3, t_sr_storeroom        t4, v_sr_shelve_detail_all   t5 where t.column_id = t2.id and t2.zone_id = t3.id and t3.storeroom_id = t4.id and t5.cell_id = t.id group by t4.id order by t4.id
/

