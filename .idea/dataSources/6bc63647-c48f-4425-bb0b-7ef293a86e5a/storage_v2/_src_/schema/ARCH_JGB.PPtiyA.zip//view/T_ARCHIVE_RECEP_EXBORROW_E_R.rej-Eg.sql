create view T_ARCHIVE_RECEP_EXBORROW_E_R as
select t.borrow_id as EXBORROW_ID,t.table_id as ARCHIVE_TYPE_ID,t.archive_id as RECORD_ID,(case t.status when '1' then '1' when '2' then '0' else '' end)as IS_EMPOWER from T_PS_BORROW_DETAIL t where t.filingtype='DATA' and t.type=1 and (t.status=1 or t.status=2)
/

