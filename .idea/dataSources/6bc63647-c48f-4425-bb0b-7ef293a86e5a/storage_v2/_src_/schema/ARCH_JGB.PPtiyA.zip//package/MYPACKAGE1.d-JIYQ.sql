create package mypackage1 is
procedure pro1(in_id varchar2);
function fun1(in_id varchar2) return varchar2;
end;

/

