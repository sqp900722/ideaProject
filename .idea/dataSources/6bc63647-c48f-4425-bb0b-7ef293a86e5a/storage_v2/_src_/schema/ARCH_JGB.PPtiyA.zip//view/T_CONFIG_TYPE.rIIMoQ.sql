create view T_CONFIG_TYPE as
select
       t1.id CODE,
       t3.group_name NAME,
       t3.id UNIQUE_CODE,
       '1' USE_FLAG,
       t1.table_tree_id SUPER_ID,
       t1.created TABLE_FLAG,
       '0' LB,
       (case when t1.logic_table_code='FILE' then '1' when t1.logic_table_code='DATA' then '1' else '0' end) ATTH_FLAG,
       '0' ATTH_TYPE
from t_xtpz_physical_table_define t1,t_xtpz_physical_group_relation t2, t_xtpz_physical_group_define t3
where t3.id=t2.group_id and t2.table_id=t1.id
/

