create package body mypackage1 is
procedure pro1(in_id varchar2) is
  v_title varchar2(100);
  begin
    select title_proper into v_title from t_ar_wslj_folder where id=in_id;
    dbms_output.put_line('???: '||v_title);
    exception
      when no_data_found then
        dbms_output.put_line('????????');
        end;
function fun1(in_id varchar2) return varchar2 is
  v_title varchar2(100);
  begin
     select title_proper into v_title from t_ar_wslj_folder where id=in_id;
     return v_title;
    exception
      when no_data_found then
        dbms_output.put_line('????????');
        end;
end;

/

