create view V_ARCHIVE_BORROW_ST_USING as
select substr(a.borrow_date, 0, 4) as borrow_year,
       substr(b.return_date, 0, 4) as return_year,
       b.group_name,
       a.borrow_dept,
       case
         when b.borrow_way = '1' then
          '电子借阅'
         when b.borrow_way = '2' then
          '实体借阅'
       end as borrow_type,
       case
         when d.logic_table_code = 'FOLDER' then
          '案卷'
         when d.logic_table_code = 'FILE' then
          '文件'
         when d.logic_table_code = 'PROJECT' then
          '项目'
       end as filingtypename
  from t_ps_archive_borrow          a,
       t_ps_archive_borrow_detail   b,
       t_xtpz_physical_table_define d
 where a.id = b.owner_id
   and b.table_id = d.id
   and b.isreally_borrowed = '1'
/

