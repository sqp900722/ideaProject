create view V_ASSEMBLE_COMPONENT_VERSION as
select 			    t.id component_version_id, 			    c.alias as component_version_name, 			    ctt.id as binding_component_version_id, 			    ctc.alias as binding_component_version_name			  from t_xtpz_component_version t			  join t_xtpz_component c on t.component_id = c.id and c.type = '9'			  join t_xtpz_construct ct on ct.component_version_id = t.id			  join t_xtpz_construct_detail ctd on ctd.construct_id = ct.id			  join t_xtpz_component_version ctt on ctd.component_version_id = ctt.id			  join t_xtpz_component ctc			    on ctt.component_id = ctc.id			  order by t.id
/

