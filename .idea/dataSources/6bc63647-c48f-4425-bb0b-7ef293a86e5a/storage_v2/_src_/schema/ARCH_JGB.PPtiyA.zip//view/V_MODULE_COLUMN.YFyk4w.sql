create view V_MODULE_COLUMN as
select t.id,
case when t.component_version_id = '-1' then '????' else m.name end as module_name,
  t.column_name,
  t.show_name,
  t.column_alias,
  t.table_id
from t_xtpz_app_column t
left join t_xtpz_module m on t.component_version_id=m.id
/

