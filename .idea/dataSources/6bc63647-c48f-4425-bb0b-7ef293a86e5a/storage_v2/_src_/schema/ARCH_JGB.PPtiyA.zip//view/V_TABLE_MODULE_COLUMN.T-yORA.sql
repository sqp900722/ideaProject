create view V_TABLE_MODULE_COLUMN as
select
t.id,
td.name table_name,
t.module_name,
t.column_name,
t.show_name,
t.column_alias

from v_module_column t
join t_xtpz_table_define td on t.table_id=td.id
/

