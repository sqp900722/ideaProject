create view V_SR_CELLCOUNT_CAPACITY as
select t4.id store_room_id, count(t.id) cell_count, sum(t.capacity) capacity from t_sr_storeroom_cell   t, t_sr_storeroom_column t2, t_sr_storeroom_zone   t3, t_sr_storeroom        t4 where t.column_id = t2.id and t2.zone_id = t3.id and t3.storeroom_id = t4.id group by t4.id order by t4.id
/

