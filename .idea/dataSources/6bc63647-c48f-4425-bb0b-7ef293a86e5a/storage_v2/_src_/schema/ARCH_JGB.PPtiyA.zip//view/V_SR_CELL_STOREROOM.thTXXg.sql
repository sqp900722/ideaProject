create view V_SR_CELL_STOREROOM as
select t.id cell_id,t.location_code,t4.id storeroom_id,t4.storeroom_name from t_sr_storeroom_cell   t, t_sr_storeroom_column t2, t_sr_storeroom_zone   t3, t_sr_storeroom        t4 where t.column_id = t2.id and t2.zone_id = t3.id and t3.storeroom_id = t4.id
/

