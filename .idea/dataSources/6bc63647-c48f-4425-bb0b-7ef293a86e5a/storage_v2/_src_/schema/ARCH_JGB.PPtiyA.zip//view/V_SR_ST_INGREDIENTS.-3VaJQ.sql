create view V_SR_ST_INGREDIENTS as
select s.storeroom_name, a.archive_type,filingtype from v_archive_total           a, v_sr_cell_storeroom       s, t_sr_shelve_detail_entity e where (a.filingtype = 'FOLDER' or a.filingtype = 'FILE') and a.shelves_status = '1' and e.storeroom_status = '1' and s.cell_id = e.cell_id
/

